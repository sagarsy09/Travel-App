 package com.qsp.TravelApp.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.qsp.TravelApp.entity.Country;
import com.qsp.TravelApp.entity.Place;
import com.qsp.TravelApp.repository.CountryRepository;
import com.qsp.TravelApp.repository.PlaceRepository;


@Repository
public class CountryDao {
	
	@Autowired
	private CountryRepository repository;
	
	@Autowired
	private PlaceRepository placerepository;

	public Country saveCountryt(Country country)
	{
		List<Place> list = country.getPlaces();
		if(list!=null) {
			for (Place place : list) {
				place.setCountry(country);
//				placerepository.save(place);
			}
		}
		return repository.save(country);
	}
	
	public Country findById(int id)
	{
		Optional<Country> optional = repository.findById(id);
		if(optional.isPresent())
		{
			return optional.get();
		}
		return null;
	}
	
	public String deleteById(int id)
	{
		Country passport = findById(id);
		if(passport!=null)
		{
			repository.deleteById(id);
			return "Country Deleted";
		}
		return "Id not found";
		
	}
	
	public List<Country> findAll()
	{
		return repository.findAll();
	}


}
