package com.qsp.TravelApp.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.qsp.TravelApp.entity.Traveller;

public interface TravellerRepository extends JpaRepository<Traveller, Integer>{

	Traveller findByName(String name);
	Traveller findByPassword(String password);
	void deleteByPassword(String password);
	
	String findByEmailAndPassword(String email, String password);
	
}
