package com.qsp.TravelApp.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.qsp.TravelApp.dto.ResponseStructure;

@RestControllerAdvice
public class TravellerExceptionHandler {
	
	@ExceptionHandler(EmailNotValidatorException.class)
	public ResponseEntity<ResponseStructure<String>> emialValidato(EmailNotValidatorException e){
		ResponseStructure<String> structure = new ResponseStructure<String>();
		structure.setStatusCode(HttpStatus.BAD_REQUEST.value());
		structure.setMessage("Email is not valid!");
		structure.setData(e.getMessage());
		return new ResponseEntity<ResponseStructure<String>>(structure , HttpStatus.BAD_REQUEST);
	}
}
