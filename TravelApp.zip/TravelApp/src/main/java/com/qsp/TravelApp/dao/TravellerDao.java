 package com.qsp.TravelApp.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailSender;
import org.springframework.stereotype.Repository;

import com.qsp.TravelApp.entity.Country;
import com.qsp.TravelApp.entity.Passport;
import com.qsp.TravelApp.entity.Traveller;
import com.qsp.TravelApp.repository.TravellerRepository;
import com.qsp.TravelApp.service.MailSenderService;

@Repository
public class TravellerDao {
	
	@Autowired
	private TravellerRepository repository;
	
	@Autowired
	private CountryDao dao;
	
	@Autowired
	private MailSenderService mailSenderService;
	
	
	public Traveller saveTraveller(Traveller traveller)
	{
		List<Country> countries = traveller.getCountries();
		
		if(countries != null) {
			for(Country country : countries) {
				dao.saveCountryt(country);
			}
		}
		
		Traveller savedTraveller = repository.save(traveller);
		
		String subject = "Welcome to the Travller App";
		
		String body = String.format("Dear %s , \n\nThank you for registrastion with us. \n\nBest Regards, \nTraveller App Team", savedTraveller.getName());
		
		mailSenderService.sendEmail(traveller.getEmail(), subject, body);
		
		return savedTraveller;
//		Passport passport = traveller.getPassport();
//		if(passport != null) {
//			
//			traveller.setPassport(passport);
//			
//		}
//		return repository.save(traveller);
	}
	
	public Traveller findById(int id)
	{
		Optional<Traveller> optional = repository.findById(id);
		if(optional.isPresent())
		{
			return optional.get();
		}
		return null;
	}
	
	
	public String deleteById(int id)
	{
		Traveller traveller = findById(id);
		if(traveller!=null)
		{
			repository.deleteById(id);
			return "Traveller Deleted";
		}
		return "Id not found";
		
	}
	
	
	public List<Traveller> findAll()
	{
		return repository.findAll();
	}

		
	public String logInTravller(String email , String pass) {
		String returnTravller = repository.findByEmailAndPassword(email, pass);
		if(returnTravller != null) {
			return "Log in Succefully!";
		}
		return "Unauthorized User!";
	}
	
	
	public Traveller giveCountriesToTraveller(int countryId , int travellerId) {
		Country returnedCountry = dao.findById(countryId);
		Optional<Traveller> travellerOptional = repository.findById(travellerId);
		
		
		if(returnedCountry != null && travellerOptional.isPresent()) {
			Traveller traveller = travellerOptional.get();
			List<Country> countries = traveller.getCountries();
			countries.add(returnedCountry);
			traveller.setContries(countries);
			return repository.save(traveller);
		}	
		return null;
	}
	
//	public Traveller findByName(String name)
//	{
//		return repository.findByName(name);
//		
//	}
	
//	public Traveller findByPassword(int password)
//	{
//		return repository.findByPassword(password);
//		
//	}
//	
//	public String deleteByPassword(int password)
//	{
//		Traveller traveller = findByPassword(password);
//		if(traveller!=null)
//		{
//			repository.deleteByPassword(password);
//			return "Traveller Deleted";
//		}
//		return "Id not found";
//	}
}
