package com.qsp.TravelApp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.qsp.TravelApp.dao.CountryDao;

import com.qsp.TravelApp.dto.ResponseStructure;
import com.qsp.TravelApp.entity.Country;


@Service
public class CountryServices {
	
	@Autowired
	private CountryDao dao;
	
	public ResponseEntity<ResponseStructure<Country>> saveCountry(Country country)
	{
		Country country1 = dao.saveCountryt(country);
		
		ResponseStructure<Country> structure = new ResponseStructure<Country>();
		structure.setStatusCode(HttpStatus.CREATED.value());
		structure.setMessage("Country Inserted");
		structure.setData(country);
		
		return new ResponseEntity<ResponseStructure<Country>>(structure,HttpStatus.CREATED);
		
	}
	
	public ResponseEntity<ResponseStructure<Country>> findById(int id)
	{
		Country country1 = dao.findById(id);
		
		ResponseStructure<Country> structure = new ResponseStructure<Country>();
		structure.setStatusCode(HttpStatus.OK.value());
		structure.setMessage("Country Retrived successfully");
		structure.setData(country1);
		
		return new ResponseEntity<ResponseStructure<Country>>(structure,HttpStatus.OK);
		
	}
	
	public ResponseEntity<ResponseStructure<String>> deleteById(int id)
	{
		String msg = dao.deleteById(id);
		
		ResponseStructure<String> structure = new ResponseStructure<String>();
		structure.setStatusCode(HttpStatus.OK.value());
		structure.setMessage("Country deleted successfully");
		structure.setData(msg);
		
		return new ResponseEntity<ResponseStructure<String>>(structure,HttpStatus.OK);
		
	}

	
	public ResponseEntity<ResponseStructure<List<Country>>> findAll()
	{
		List<Country> country1 = dao.findAll();
		
		ResponseStructure<List<Country>> structure = new ResponseStructure<List<Country>>();
		structure.setStatusCode(HttpStatus.OK.value());
		structure.setMessage("All countries are retrive successfully");
		structure.setData(country1);
		
		return new ResponseEntity<ResponseStructure<List<Country>>>(structure,HttpStatus.OK);
		
	}
	

}
