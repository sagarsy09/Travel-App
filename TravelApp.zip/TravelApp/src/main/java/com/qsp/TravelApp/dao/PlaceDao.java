package com.qsp.TravelApp.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.qsp.TravelApp.entity.Place;
import com.qsp.TravelApp.repository.PlaceRepository;

@Repository
public class PlaceDao {
	
	@Autowired
	private PlaceRepository repository;
	

	public Place savePlace(Place place)
	{
		
		return repository.save(place);
	}
	
	public Place findById(int id)
	{
		Optional<Place> optional = repository.findById(id);
		if(optional.isPresent())
		{
			return optional.get();
		}
		return null;
	}
	
	public String deleteById(int id)
	{
		Place place = findById(id);
		if(place!=null)
		{
			repository.deleteById(id);
			return "Place Deleted";
		}
		return "Id not found";
		
	}
	
	public List<Place> findAll()
	{
		return repository.findAll();
	}

	
	

}
