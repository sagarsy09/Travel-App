package com.qsp.TravelApp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.qsp.TravelApp.dto.ResponseStructure;
import com.qsp.TravelApp.entity.Place;
import com.qsp.TravelApp.service.PlaceService;

@RestController
public class PlaceController {
	
	@Autowired
	private PlaceService service;
	
	
	@PostMapping("/place")
	public ResponseEntity<ResponseStructure<Place>> savePlace(@RequestBody Place place)
	{
		return service.savePlace(place);
	}
	
	@GetMapping("/place/{id}")
	public ResponseEntity<ResponseStructure<Place>> findById(@PathVariable int id)
	{
		return service.findById(id);
	}
	
	@DeleteMapping("/place/{id}")
	public ResponseEntity<ResponseStructure<String>> deleteById(@PathVariable int id)
	{
		return service.deleteById(id);
	}
	
	@GetMapping("/placeall")
	public ResponseEntity<ResponseStructure<List<Place>>> findAll()
	{
		return service.findAll();
	}
	
	
	
//	@GetMapping("/place/{name}")
//	public ResponseEntity<ResponseStructure<Place>> findByName(@PathVariable String name)
//	{
//		return service.findByName(name);
//	}

	
//	@DeleteMapping("/place/{name}")
//	public ResponseEntity<ResponseStructure<String>> deleteByName(@PathVariable String name)
//	{
//		return service.deleteByName(name);
//	}
}
