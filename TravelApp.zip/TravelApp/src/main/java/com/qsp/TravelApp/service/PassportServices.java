package com.qsp.TravelApp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.qsp.TravelApp.dao.PassportDao;

import com.qsp.TravelApp.dto.ResponseStructure;
import com.qsp.TravelApp.entity.Passport;


@Service
public class PassportServices {
	
	@Autowired
	private PassportDao dao;
	
	
	public ResponseEntity<ResponseStructure<Passport>> savePassport(Passport passport)
	{
		Passport passport1 = dao.savePassport(passport);
		
		ResponseStructure<Passport> structure = new ResponseStructure<Passport>();
		structure.setStatusCode(HttpStatus.CREATED.value());
		structure.setMessage("Passport Inserted");
		structure.setData(passport1);
		
		return new ResponseEntity<ResponseStructure<Passport>>(structure,HttpStatus.CREATED);
		
	}
	
	
	public ResponseEntity<ResponseStructure<Passport>> findById(int id)
	{
		Passport passport1 = dao.findById(id);
		
		ResponseStructure<Passport> structure = new ResponseStructure<Passport>();
		structure.setStatusCode(HttpStatus.OK.value());
		structure.setMessage("Passport retrived");
		structure.setData(passport1);
		
		return new ResponseEntity<ResponseStructure<Passport>>(structure,HttpStatus.OK);
		
	}
	
	
	
	public ResponseEntity<ResponseStructure<String>> deleteById(int id)
	{
		String msg = dao.deleteById(id);
		
		ResponseStructure<String> structure = new ResponseStructure<String>();
		structure.setStatusCode(HttpStatus.OK.value());
		structure.setMessage("Passport deleted");
		structure.setData(msg);
		
		return new ResponseEntity<ResponseStructure<String>>(structure,HttpStatus.OK);
		
	}
	
	
	
	public ResponseEntity<ResponseStructure<List<Passport>>> findAll()
	{
		List<Passport> list = dao.findAll();
		
		ResponseStructure<List<Passport>> structure = new ResponseStructure<List<Passport>>();
		structure.setStatusCode(HttpStatus.OK.value());
		structure.setMessage("All Passports retrived");
		structure.setData(list);
		
		return new ResponseEntity<ResponseStructure<List<Passport>>>(structure,HttpStatus.OK);
	}
	
	

	
//	public ResponseEntity<ResponseStructure<String>> deleteByPassportNumber(String passportNumber)
//	{
//		String msg = dao.deleteByPassportNumber(passportNumber);
//		
//		ResponseStructure<String> structure = new ResponseStructure<String>();
//		structure.setStatusCode(HttpStatus.OK.value());
//		structure.setMessage("Passport is deleted");
//		structure.setData(msg);
//		
//		return new ResponseEntity<ResponseStructure<String>>(structure,HttpStatus.OK);
//		
//	}
	

}
