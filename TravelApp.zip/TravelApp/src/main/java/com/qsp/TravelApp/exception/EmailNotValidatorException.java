package com.qsp.TravelApp.exception;

public class EmailNotValidatorException extends RuntimeException {
		@Override
		public String getMessage() {
			// TODO Auto-generated method stub
			return "Please enter valid email address!";
		}
}	
