package com.qsp.TravelApp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.qsp.TravelApp.dao.PlaceDao;

import com.qsp.TravelApp.dto.ResponseStructure;
import com.qsp.TravelApp.entity.Place;


@Service
public class PlaceService {

	
	@Autowired
	private PlaceDao dao;
	
	public ResponseEntity<ResponseStructure<Place>> savePlace(Place place)
	{
		Place place1 = dao.savePlace(place);
		
		ResponseStructure<Place> structure = new ResponseStructure<Place>();
		structure.setStatusCode(HttpStatus.CREATED.value());
		structure.setMessage("Place Inserted");
		structure.setData(place1);
		
		return new ResponseEntity<ResponseStructure<Place>>(structure,HttpStatus.CREATED);
		
	}
	
	public ResponseEntity<ResponseStructure<Place>> findById(int id)
	{
		Place place1 = dao.findById(id);
		
		ResponseStructure<Place> structure = new ResponseStructure<Place>();
		structure.setStatusCode(HttpStatus.OK.value());
		structure.setMessage("Place retrived");
		structure.setData(place1);
		
		return new ResponseEntity<ResponseStructure<Place>>(structure,HttpStatus.OK);
		
	}
	

	
	public ResponseEntity<ResponseStructure<String>> deleteById(int id)
	{
		String msg = dao.deleteById(id);
		
		ResponseStructure<String> structure = new ResponseStructure<String>();
		structure.setStatusCode(HttpStatus.OK.value());
		structure.setMessage("Place deleted");
		structure.setData(msg);
		
		return new ResponseEntity<ResponseStructure<String>>(structure,HttpStatus.OK);
		
	}
	

	
	public ResponseEntity<ResponseStructure<List<Place>>> findAll()
	{
		List<Place> list = dao.findAll();
		
		ResponseStructure<List<Place>> structure = new ResponseStructure<List<Place>>();
		structure.setStatusCode(HttpStatus.OK.value());
		structure.setMessage("All Places retrived");
		structure.setData(list);
		
		return new ResponseEntity<ResponseStructure<List<Place>>>(structure,HttpStatus.OK);
	}
	
	
	
//	public ResponseEntity<ResponseStructure<String>> deleteByName(String name)
//	{
//		String msg = dao.deleteByName(name);
//		
//		ResponseStructure<String> structure = new ResponseStructure<String>();
//		structure.setStatusCode(HttpStatus.OK.value());
//		structure.setMessage("place  is deleted");
//		structure.setData(msg);
//		
//		return new ResponseEntity<ResponseStructure<String>>(structure,HttpStatus.OK);
//		
//	}
}
