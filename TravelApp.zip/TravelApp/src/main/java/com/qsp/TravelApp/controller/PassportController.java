package com.qsp.TravelApp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.qsp.TravelApp.dto.ResponseStructure;
import com.qsp.TravelApp.entity.Passport;
import com.qsp.TravelApp.entity.Place;
import com.qsp.TravelApp.service.PassportServices;

@RestController
public class PassportController {
	
	@Autowired
	private PassportServices service;
	
	
	@PostMapping("/passport")
	public ResponseEntity<ResponseStructure<Passport>> savePlace(@RequestBody Passport passport)
	{
		return service.savePassport(passport);
	}
	
	@GetMapping("/passport/{id}")
	public ResponseEntity<ResponseStructure<Passport>> findById(@PathVariable int id)
	{
		return service.findById(id);
	}
	
	@DeleteMapping("/passport/{id}")
	public ResponseEntity<ResponseStructure<String>> deleteById(@PathVariable int id)
	{
		return service.deleteById(id);
	}
	
	@GetMapping("/passportall")
	public ResponseEntity<ResponseStructure<List<Passport>>> findAll()
	{
		return service.findAll();
	}
	
	
	
	
//	
//	@GetMapping("/passport/{name}")
//	public ResponseEntity<ResponseStructure<Passport>> findByPassportNumber(@PathVariable String passportNumber)
//	{
//		return service.findByPassportNumber(passportNumber);
//	}
//
//	
//	@DeleteMapping("/passport/{name}")
//	public ResponseEntity<ResponseStructure<String>> deleteByPassportNumber(@PathVariable String passportNumber)
//	{
//		return service.deleteByPassportNumber(passportNumber);
//	}

}
