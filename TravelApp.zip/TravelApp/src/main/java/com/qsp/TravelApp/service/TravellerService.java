package com.qsp.TravelApp.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.qsp.TravelApp.dao.TravellerDao;
import com.qsp.TravelApp.dto.ResponseStructure;
import com.qsp.TravelApp.entity.Traveller;
import com.qsp.TravelApp.exception.EmailNotValidatorException;

@Service
public class TravellerService {
	
	@Autowired
	private TravellerDao dao;
	
	public ResponseEntity<ResponseStructure<Traveller>> saveTraveller(Traveller traveller)
	{
		if(EmailValidator.isValidEmail(traveller.getEmail())) {
			Traveller traveller1 = dao.saveTraveller(traveller);
			
			ResponseStructure<Traveller> structure = new ResponseStructure<Traveller>();
			structure.setStatusCode(HttpStatus.CREATED.value());
			structure.setMessage("Traveller Inserted");
			structure.setData(traveller1);
			
			return new ResponseEntity<ResponseStructure<Traveller>>(structure,HttpStatus.CREATED);
		}
		
		throw new EmailNotValidatorException();
	}
	
	public ResponseEntity<ResponseStructure<Traveller>> findById(int id)
	{
		Traveller traveller1 = dao.findById(id);
		
		ResponseStructure<Traveller> structure = new ResponseStructure<Traveller>();
		structure.setStatusCode(HttpStatus.OK.value());
		structure.setMessage("Traveller Retrived successfully");
		structure.setData(traveller1);
		
		return new ResponseEntity<ResponseStructure<Traveller>>(structure,HttpStatus.OK);
		
	}
	
	
	
	public ResponseEntity<ResponseStructure<String>> deleteById(int id)
	{
		String msg = dao.deleteById(id);
		
		ResponseStructure<String> structure = new ResponseStructure<String>();
		structure.setStatusCode(HttpStatus.OK.value());
		structure.setMessage("Traveller deleted successfully");
		structure.setData(msg);
		
		return new ResponseEntity<ResponseStructure<String>>(structure,HttpStatus.OK);
		
	}
	
		

	
	public ResponseEntity<ResponseStructure<List<Traveller>>> findAll()
	{
		List<Traveller> traveller1 = dao.findAll();
		
		ResponseStructure<List<Traveller>> structure = new ResponseStructure<List<Traveller>>();
		structure.setStatusCode(HttpStatus.OK.value());
		structure.setMessage("All Travellers are retrive successfully");
		structure.setData(traveller1);
		
		return new ResponseEntity<ResponseStructure<List<Traveller>>>(structure,HttpStatus.OK);
		
	}

	public ResponseEntity<ResponseStructure<String>> travellerLogIn(String email, String pass) {
		String logInTravller = dao.logInTravller(email, pass);
		
		ResponseStructure<String> structure = new ResponseStructure<String>();
		structure.setStatusCode(HttpStatus.OK.value());
		structure.setMessage("Log in Succefully!");
		structure.setData(logInTravller);
		
		return new ResponseEntity<ResponseStructure<String>>(structure , HttpStatus.OK);
	}
	
	
	public ResponseEntity<ResponseStructure<Traveller>> giveCountryToTraveller(int countryId , int travellerId){
		Traveller countriesToTraveller = dao.giveCountriesToTraveller(countryId, travellerId);
		
		ResponseStructure<Traveller> structure = new ResponseStructure<Traveller>();
		structure.setStatusCode(HttpStatus.OK.value());
		structure.setMessage("Country is assigned to the traveller!");
		structure.setData(countriesToTraveller);
		
		return new ResponseEntity<ResponseStructure<Traveller>>(structure , HttpStatus.OK);
	}
	
//	public ResponseEntity<ResponseStructure<String>> deleteByPassword(int password)
//	{
//		String msg = dao.deleteByPassword(password);
//		
//		ResponseStructure<String> structure = new ResponseStructure<String>();
//		structure.setStatusCode(HttpStatus.OK.value());
//		structure.setMessage("Traveller deleted successfully");
//		structure.setData(msg);
//		
//		return new ResponseEntity<ResponseStructure<String>>(structure,HttpStatus.OK);
//		
//	}
	
	
//	
//	public ResponseEntity<ResponseStructure<Traveller>> findByPassword(int password)
//	{
//		Traveller traveller1 = dao.findByPassword(password);
//		
//		ResponseStructure<Traveller> structure = new ResponseStructure<Traveller>();
//		structure.setStatusCode(HttpStatus.OK.value());
//		structure.setMessage("Traveller Retrived successfully");
//		structure.setData(traveller1);
//		
//		return new ResponseEntity<ResponseStructure<Traveller>>(structure,HttpStatus.OK);
//		
//	}

}
