package com.qsp.TravelApp.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.qsp.TravelApp.entity.Place;


public interface PlaceRepository extends JpaRepository<Place, Integer> {

	Place findByName(String name);
}
