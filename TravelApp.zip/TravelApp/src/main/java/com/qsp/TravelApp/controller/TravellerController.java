package com.qsp.TravelApp.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.qsp.TravelApp.dto.ResponseStructure;
import com.qsp.TravelApp.entity.Traveller;
import com.qsp.TravelApp.service.TravellerService;

@RestController
public class TravellerController {
	
	@Autowired
	private TravellerService service;
	
	@PostMapping("/traveller")
	public ResponseEntity<ResponseStructure<Traveller>> saveTraveller(@RequestBody Traveller traveller)
	{
		return service.saveTraveller(traveller);
	}
	
	@GetMapping("/traveller/{id}")
	public ResponseEntity<ResponseStructure<Traveller>> findById(@PathVariable int id)
	{
		return service.findById(id);
	}
	
	@GetMapping("/alltraveller")
	public ResponseEntity<ResponseStructure<List<Traveller>>> findAll()
	{
		return service.findAll();
	}
	
	
	@DeleteMapping("/traveller/{id}")
	public ResponseEntity<ResponseStructure<String>> deleteById(@PathVariable int id)
	{
		return service.deleteById(id);
	}
	
	
	
	@PostMapping("/login")
	public ResponseEntity<ResponseStructure<String>> logIn(String email , String pass){
		return service.travellerLogIn(email , pass);
	}
	
	
	
	
	@PutMapping("/countryToTraveller/{cId}/{tId}")
	public ResponseEntity<ResponseStructure<Traveller>> giveCountryToTraveller(@PathVariable int cId , @PathVariable int tId){
		return service.giveCountryToTraveller(cId, tId);
	}
	
	
	
//	@GetMapping("/traveller/{password}")
//	public ResponseEntity<ResponseStructure<Traveller>> findByPassword(@PathVariable int password)
//	{
//		return service.findByPassword(password);
//	}
	
//	@DeleteMapping("/traveller")
//	public ResponseEntity<ResponseStructure<String>> deleteByPassword(@RequestParam int password)
//	{
//		return service.deleteByPassword(password);
//	}

}
