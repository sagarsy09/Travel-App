package com.qsp.TravelApp.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.qsp.TravelApp.entity.Passport;

public interface PassportRepository extends JpaRepository<Passport, Integer> {

	Passport findByPassportNumber(String passportNumber);
}
