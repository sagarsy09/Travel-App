package com.qsp.TravelApp.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.qsp.TravelApp.entity.Passport;
import com.qsp.TravelApp.entity.Traveller;
import com.qsp.TravelApp.repository.PassportRepository;
import com.qsp.TravelApp.repository.TravellerRepository;

@Repository
public class PassportDao {
	
	@Autowired
	private PassportRepository repository;
	private TravellerRepository travelRepository;

	public Passport savePassport(Passport passport)
	{
		Traveller traveller=passport.getTraveller();
		passport.setTraveller(traveller);
		return repository.save(passport);
	}
	
	public Passport findById(int id)
	{
		Optional<Passport> optional = repository.findById(id);
		if(optional.isPresent())
		{
			return optional.get();
		}
		return null;
	}
	
	
	public String deleteById(int id)
	{
		Passport passport = findById(id);
		if(passport!=null)
		{
			repository.deleteById(id);
			return "Passport Deleted";
		}
		return "Id not found";
		
	}
	
	public List<Passport> findAll()
	{
		return repository.findAll();
	}

	
	
//	public Passport findByPassportNumber(String passportNumber)
//	{
//		return repository.findByPassportNumber(passportNumber);
//	}

}
