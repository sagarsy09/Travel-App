package com.qsp.TravelApp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.qsp.TravelApp.dto.ResponseStructure;
import com.qsp.TravelApp.entity.Country;
import com.qsp.TravelApp.entity.Passport;
import com.qsp.TravelApp.entity.Place;
import com.qsp.TravelApp.service.CountryServices;

@RestController
public class CountryController {
	
	@Autowired
	private CountryServices service;
	
	@PostMapping("/country")
	public ResponseEntity<ResponseStructure<Country>> saveCountry(@RequestBody Country country)
	{
		return service.saveCountry(country);
	}
	
	@GetMapping("/country/{id}")
	public ResponseEntity<ResponseStructure<Country>> findById(@PathVariable int id)
	{
		return service.findById(id);
	}
	
	@DeleteMapping("/country/{id}")
	public ResponseEntity<ResponseStructure<String>> deleteById(@PathVariable int id)
	{
		return service.deleteById(id);
	}

	
	@GetMapping("/countryall")
	public ResponseEntity<ResponseStructure<List<Country>>> findAll()
	{
		return service.findAll();
	}
	
	
	
	
	
//	@GetMapping("/country/{name}")
//	public ResponseEntity<ResponseStructure<Country>> findByName(@PathVariable String name)
//	{
//		return services.findByName(name);
//	}
//	
//
//	@DeleteMapping("/country/{name}")
//	public ResponseEntity<ResponseStructure<String>> deleteByName(@PathVariable String name)
//	{
//		return services.deleteByName(name);
//	}

}
